# hxmaker-openfl
OpenFL target backend for running hxmaker game engine

# platform
| platform | description |
| -------- | ----------- |
| game4399 | 4399 game platform |